export const SHOWMODAL = 'showModal';
export const HIDEMODAL = 'hideModal';
export const SHOWMODAL_ASYNC = 'showModal_async';