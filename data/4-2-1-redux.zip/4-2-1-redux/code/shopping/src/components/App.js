import React from 'react';
import Product from './product';
import Cart from './cart';

function App() {
  return <div>
    <Product />
    <Cart/>
  </div>;
}

export default App;
